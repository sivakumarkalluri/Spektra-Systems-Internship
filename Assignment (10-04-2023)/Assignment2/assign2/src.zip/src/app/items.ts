export interface items{
    id:string,
    itemName:string,
    type:string,
    price:number
    qty:number
}